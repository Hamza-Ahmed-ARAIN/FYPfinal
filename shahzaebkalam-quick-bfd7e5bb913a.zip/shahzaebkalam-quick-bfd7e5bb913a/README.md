firstly clone this repository p
then then unzip it.

## How to install code 

```
npm install
or 
yarn install
```